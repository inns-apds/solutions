import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import com.google.gson.JsonObject;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;


import constants.IKafkaConstants;
import consumer.ConsumerCreator;
import producer.ProducerCreator;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import javax.imageio.ImageIO;

public class Grayscale {

    public static JsonObject main(JsonObject args) {
        JsonObject response = new JsonObject();
        Consumer<Long, String> consumer = ConsumerCreator.createConsumer();
        int noMessageToFetch = 0;

        for (int index = 0; index < 5; index++) {


            final ConsumerRecords<Long, String> consumerRecords = consumer.poll(100);
            if (consumerRecords.count() == 0) {
                noMessageToFetch++;
                if (noMessageToFetch > IKafkaConstants.MAX_NO_MESSAGE_FOUND_COUNT)
                    break;

                else
                    continue;
            }

            for (ConsumerRecord<Long, String> record : consumerRecords) {
                BufferedImage image = decodeToImage(record.value());
                BufferedImage watermarkedImage = grayscaleMethod(image);
                String imageString = encodeToString(watermarkedImage,"jpg");
                runProducer(imageString);
                System.out.println("Successfully converted");
                response.addProperty("Key", record.value());
                String imageParam = "stranger";
                if (args.has("image"))
                    imageParam = args.getAsJsonPrimitive("image").getAsString();
                invocation(imageParam);
            }
            response.addProperty("Grayscale","ok");
            consumer.commitAsync();
        }
        consumer.close();
        return response;
    }

    public static void runProducer(String imageString) {
        Producer<Long, String> producer = ProducerCreator.createProducer();

        for (int index = 0; index < IKafkaConstants.MESSAGE_COUNT; index++) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm:ss");
            Calendar calendar = Calendar.getInstance();
            final ProducerRecord<Long, String> record = new ProducerRecord<Long, String>("topic5",
                    imageString);
            try {
                RecordMetadata metadata = producer.send(record).get();
                System.out.println(dateFormat.format(calendar.getTime()));
                System.out.println("Record sent with key " + index + " to partition " + metadata.partition()
                        + " with offset " + metadata.offset());
            } catch (ExecutionException e) {
                System.out.println("Error in sending record");
                System.out.println(e);
            } catch (InterruptedException e) {
                System.out.println("Error in sending record");
                System.out.println(e);
            }
        }
    }
    public static String encodeToString(BufferedImage image, String type) {
        String imageString = null;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            ImageIO.write(image, type, bos);
            byte[] imageBytes = bos.toByteArray();
            BASE64Encoder encoder = new BASE64Encoder();
            imageString = encoder.encode(imageBytes);
            bos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return imageString;
    }
    public static BufferedImage grayscaleMethod(BufferedImage image) {
        int width;
        int height;
        width = image.getWidth();
        height = image.getHeight();

        for(int i=0; i<height; i++) {

            for(int j=0; j<width; j++) {

                Color c = new Color(image.getRGB(j, i));
                int red = (int)(c.getRed() * 0.299);
                int green = (int)(c.getGreen() * 0.587);
                int blue = (int)(c.getBlue() *0.114);
                Color newColor = new Color(red+green+blue,

                        red+green+blue,red+green+blue);

                image.setRGB(j,i,newColor.getRGB());
            }
        }
        return image;
    }
    public static BufferedImage decodeToImage(String imageString) {
        BufferedImage image = null;
        byte[] imageByte;
        try {
            BASE64Decoder decoder = new BASE64Decoder();
            imageByte = decoder.decodeBuffer(imageString);
            ByteArrayInputStream bis = new ByteArrayInputStream(imageByte);
            image = ImageIO.read(bis);
            bis.close();} catch (Exception e) {
        }

        return image;
    }
    public static void invocation(String image){
        try {
            URL url = new URL("https://openwhisk.eu-gb.bluemix.net/api/v1/web/mr.salehsedghpour%40yahoo.com_dev/default/zipper.json?image="+image);
            HttpURLConnection hConn = (HttpURLConnection) url.openConnection();
            hConn.setRequestProperty("Content-Type", "application/json");
            hConn.setRequestMethod("POST");
            hConn.setDoOutput(true);

            String input = "";

            OutputStream os = hConn.getOutputStream();
            os.write(input.getBytes());
            os.flush();
            os.close();

            if (hConn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                BufferedReader br =
                        new BufferedReader(new InputStreamReader(hConn.getInputStream()));

                String output;
                while ((output = br.readLine()) != null) {
                    System.out.println(output);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}