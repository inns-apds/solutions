import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.RescaleOp;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.concurrent.ExecutionException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.google.gson.JsonArray;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpHeaders;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import com.google.gson.JsonObject;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;


import constants.IKafkaConstants;
import consumer.ConsumerCreator;
import org.apache.kafka.common.protocol.types.Field;
import org.lightcouch.CouchDbClient;
import producer.ProducerCreator;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import javax.imageio.ImageIO;

public class Zipper {

    public static JsonObject main(JsonObject args) {
        JsonObject response = new JsonObject();
        Consumer<Long, String> consumer = ConsumerCreator.createConsumer();
        int noMessageToFetch = 0;
        for (int index = 0; index < 5; index++) {
            final ConsumerRecords<Long, String> consumerRecords = consumer.poll(1000);
            if (consumerRecords.count() == 0) {
                noMessageToFetch++;
                if (noMessageToFetch > IKafkaConstants.MAX_NO_MESSAGE_FOUND_COUNT)
                    break;

                else
                    continue;
            }
            for (ConsumerRecord<Long, String> record : consumerRecords) {
                String imageParam = "stranger";
                if (args.has("image"))
                    imageParam = args.getAsJsonPrimitive("image").getAsString();
                saveToCouchdb(record.value(),imageParam);


                String enhancerString = getFromCouchdb("enhanced_" + imageParam);
                String grayscaleString = getFromCouchdb("grayscaled_" + imageParam);
                if ((enhancerString != null) && (grayscaleString != null)) {
                    try {
                        BufferedImage enhancerImage = decodeToImage(enhancerString);
                        BufferedImage grayscaleImage = decodeToImage(grayscaleString);
                        File outputfile = new File("enhanced.jpg");
                        ImageIO.write(enhancerImage, "jpg", outputfile);
                        File outputfile2 = new File("grayscaled.jpg");
                        ImageIO.write(grayscaleImage, "jpg", outputfile2);
                        String zipFile = imageParam + "archive.zip";

                        String[] srcFiles = {"enhanced.jpg", "grayscaled.jpg"};
                        // create byte buffer
                        byte[] buffer = new byte[1024];

                        FileOutputStream fos = new FileOutputStream(zipFile);

                        ZipOutputStream zos = new ZipOutputStream(fos);

                        for (int i = 0; i < srcFiles.length; i++) {

                            File srcFile = new File(srcFiles[i]);

                            FileInputStream fis = new FileInputStream(srcFile);

                            // begin writing a new ZIP entry, positions the stream to the start of the entry data
                            zos.putNextEntry(new ZipEntry(srcFile.getName()));

                            int length;

                            while ((length = fis.read(buffer)) > 0) {
                                zos.write(buffer, 0, length);
                            }

                            zos.closeEntry();

                            // close the InputStream
                            fis.close();

                        }

                        // close the ZipOutputStream
                        zos.close();
                        String finalOutput = encodeFileToString(zipFile);
                        saveToCouchdb(finalOutput,"zipped_"+imageParam);


                    } catch (IOException ioe) {
                        System.out.println("Error creating zip file: " + ioe);
                    }
                }


            }

        }
        response.addProperty("Zipper", "ok");
        consumer.commitAsync();

        consumer.close();
        return response;
    }


    public static BufferedImage decodeToImage(String imageString) {
        BufferedImage image = null;
        byte[] imageByte;
        try {
            BASE64Decoder decoder = new BASE64Decoder();
            imageByte = decoder.decodeBuffer(imageString);
            ByteArrayInputStream bis = new ByteArrayInputStream(imageByte);
            image = ImageIO.read(bis);
            bis.close();} catch (Exception e) {
        }

        return image;
    }
    public static  String  getFromCouchdb(String imageID) {
        CouchDbClient dbClient = new CouchDbClient("images", true, "http", "144.76.171.37", 5985, "admin", "123456");
        JsonObject dbout = dbClient.find(JsonObject.class, imageID);
        String  image = dbout.get("image").getAsString();

        return image;
    }
    public static String saveToCouchdb(String image,String imageID){
        CouchDbClient dbClient = new CouchDbClient("images", true, "http", "144.76.171.37", 5985, "admin", "123456");
        JsonObject json = new JsonObject();
        json.addProperty("_id", imageID);
        json.addProperty("name","zipper");
        json.addProperty("zipped",image);
        dbClient.save(json);
        System.out.println("Saved to");
        return imageID;
    }
    public static String encodeFileToString(String filepath){
        File originalFile = new File(filepath);
        String encodedBase64 = null;
        try {
            FileInputStream fileInputStreamReader = new FileInputStream(originalFile);
            byte[] bytes = new byte[(int)originalFile.length()];
            fileInputStreamReader.read(bytes);
            encodedBase64 = new String(Base64.encodeBase64(bytes));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return encodedBase64;
    }


}