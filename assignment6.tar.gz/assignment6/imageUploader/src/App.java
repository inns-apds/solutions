import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.ExecutionException;
import sun.misc.BASE64Encoder;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.io.IOException;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import constants.IKafkaConstants;
import producer.ProducerCreator;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class App {
        public static void main(String[] args) {
            File folder = new File("../../images");
            File[] listOfFiles = folder.listFiles();
            for (int i = 0; i < listOfFiles.length; i++) {
                if (listOfFiles[i].isFile()) {
                    System.out.println("File " + listOfFiles[i].getName() + " is successfully loaded\n");
                    BufferedImage image = loadImage("../../images/"+listOfFiles[i].getName());
                    String imageString = encodeToString(image,"jpg");
                    System.out.println("File " + listOfFiles[i].getName() + " is successfully converted to base 64\n");
                    runProducer(imageString);
                    invocation(listOfFiles[i].getName());
                } else if (listOfFiles[i].isDirectory()) {
                    System.out.println("Directory " + listOfFiles[i].getName());
                }
            }

        }


    static void runProducer(String imageString) {
        Producer<Long, String> producer = ProducerCreator.createProducer();

        for (int index = 0; index < 1; index++) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm:ss");
            Calendar calendar = Calendar.getInstance();
            final ProducerRecord<Long, String> record = new ProducerRecord<Long, String>(IKafkaConstants.TOPIC_NAME,
                    imageString);
            try {
                RecordMetadata metadata = producer.send(record).get();
                System.out.println(dateFormat.format(calendar.getTime()));
                System.out.println("Record sent with key " + index + " to partition " + metadata.partition()
                        + " with offset " + metadata.offset());
            } catch (ExecutionException e) {
                System.out.println("Error in sending record");
                System.out.println(e);
            } catch (InterruptedException e) {
                System.out.println("Error in sending record");
                System.out.println(e);
            }
        }
    }
    public static String encodeToString(BufferedImage image, String type) {
        String imageString = null;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            ImageIO.write(image, type, bos);
            byte[] imageBytes = bos.toByteArray();
            BASE64Encoder encoder = new BASE64Encoder();
            imageString = encoder.encode(imageBytes);
            bos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return imageString;
    }
    public static BufferedImage loadImage(String imageName){
        BufferedImage img = null;
        try {
            img = ImageIO.read(new File(imageName));
        } catch (IOException e) {
        }
        return img;
    }
    static void invocation(String image){
        try {
            URL url = new URL("https://openwhisk.eu-gb.bluemix.net/api/v1/web/mr.salehsedghpour%40yahoo.com_dev/default/watermark.json");
            HttpURLConnection hConn = (HttpURLConnection) url.openConnection();
            hConn.setRequestProperty("Content-Type", "application/json");
            hConn.setRequestMethod("POST");
            hConn.setDoOutput(true);

            String input = "";

            OutputStream os = hConn.getOutputStream();
            os.write(input.getBytes());
            os.flush();
            os.close();

            if (hConn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                BufferedReader br =
                        new BufferedReader(new InputStreamReader(hConn.getInputStream()));

                String output;
                while ((output = br.readLine()) != null) {
                    System.out.println(output);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}