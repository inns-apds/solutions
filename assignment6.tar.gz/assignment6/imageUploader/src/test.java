import org.apache.http.*;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import sun.misc.BASE64Encoder;


import java.nio.charset.StandardCharsets;

/**
 * A simple Java REST GET example using the Apache HTTP library.
 * This executes a call against the Yahoo Weather API service, which is
 * actually an RSS service (http://developer.yahoo.com/weather/).
 *
 * Try this Twitter API URL for another example (it returns JSON results):
 * http://search.twitter.com/search.json?q=%40apple
 * (see this url for more twitter info: https://dev.twitter.com/docs/using-search)
 *
 * Apache HttpClient: http://hc.apache.org/httpclient-3.x/
 *
 */
public class test {

    public static void main(String[] args) {
        try {
            HttpPost request = new HttpPost("https://openwhisk.eu-gb.bluemix.net/api/v1/namespaces/mr.salehsedghpour%40yahoo.com_dev/triggers/Fork");
            BASE64Encoder encoder = new BASE64Encoder();
            byte[] userPass= "ffbb9c5a-0cc8-46c2-a6e5-8500210acebd:2LnXtVHcuOzB7Ak540HewQFfkkPnqv0gyG135gBd14WxNianT1vci9lF1uyeVvy5".getBytes("UTF-8");
            //String encoding = Base64Encoder.encode ("ffbb9c5a-0cc8-46c2-a6e5-8500210acebd:2LnXtVHcuOzB7Ak540HewQFfkkPnqv0gyG135gBd14WxNianT1vci9lF1uyeVvy5");
            String authHeader = "Basic ZmZiYjljNWEtMGNjOC00NmMyLWE2ZTUtODUwMDIxMGFjZWJkOjJMblh0VkhjdU96QjdBazU0MEhld1FGZmtrUG5xdjBneUcxMzVnQmQxNFd4TmlhblQxdmNpOWxGMXV5ZVZ2eTU=";
            request.setHeader(HttpHeaders.AUTHORIZATION, authHeader);

            HttpClient client = HttpClientBuilder.create().build();
            HttpResponse response = client.execute(request);

            System.out.println(response.getStatusLine().getStatusCode());
            int statusCode = response.getStatusLine().getStatusCode();
            //assertThat(statusCode, equalTo(HttpStatus.SC_OK));
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}