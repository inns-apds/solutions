import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.concurrent.ExecutionException;

import org.apache.http.HttpHeaders;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import com.google.gson.JsonObject;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;


import constants.IKafkaConstants;
import consumer.ConsumerCreator;
import org.apache.kafka.common.protocol.types.Field;
import producer.ProducerCreator;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import javax.imageio.ImageIO;

public class Watermark {

    public static JsonObject main(JsonObject args) {
        JsonObject response = new JsonObject();
        Consumer<Long, String> consumer = ConsumerCreator.createConsumer();
        int noMessageToFetch = 0;

        for (int index = 0; index < 5; index++) {


            final ConsumerRecords<Long, String> consumerRecords = consumer.poll(100);
            if (consumerRecords.count() == 0) {
                noMessageToFetch++;
                if (noMessageToFetch > IKafkaConstants.MAX_NO_MESSAGE_FOUND_COUNT)
                    break;

                else
                    continue;
            }

            for (ConsumerRecord<Long, String> record : consumerRecords) {
                BufferedImage image = decodeToImage(record.value());
                BufferedImage watermarkedImage = watermarkMethod(image);
                String imageString = encodeToString(watermarkedImage,"jpg");
                runProducer(imageString);
                System.out.println("Successfully converted");
                response.addProperty("Key", record.value());
                String imageParam = "stranger";
                if (args.has("image"))
                    imageParam = args.getAsJsonPrimitive("image").getAsString();
                String output=invocation(imageParam);
                response.addProperty("outputs", output);
            }
            response.addProperty("Watermark","ok");
            consumer.commitAsync();
        }
        consumer.close();
        return response;
    }

    static void runProducer(String imageString) {
        Producer<Long, String> producer = ProducerCreator.createProducer();

        for (int index = 0; index < IKafkaConstants.MESSAGE_COUNT; index++) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm:ss");
            Calendar calendar = Calendar.getInstance();
            final ProducerRecord<Long, String> record = new ProducerRecord<Long, String>("topic2",
                    imageString);
            try {
                RecordMetadata metadata = producer.send(record).get();
                System.out.println(dateFormat.format(calendar.getTime()));
                System.out.println("Record sent with key " + index + " to partition " + metadata.partition()
                        + " with offset " + metadata.offset());
            } catch (ExecutionException e) {
                System.out.println("Error in sending record");
                System.out.println(e);
            } catch (InterruptedException e) {
                System.out.println("Error in sending record");
                System.out.println(e);
            }
        }
        Producer<Long, String> producer2 = ProducerCreator.createProducer();

        for (int index = 0; index < IKafkaConstants.MESSAGE_COUNT; index++) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm:ss");
            Calendar calendar = Calendar.getInstance();
            final ProducerRecord<Long, String> record = new ProducerRecord<Long, String>("topic3",
                    imageString);
            try {
                RecordMetadata metadata = producer2.send(record).get();
                System.out.println(dateFormat.format(calendar.getTime()));
                System.out.println("Record sent with key " + index + " to partition " + metadata.partition()
                        + " with offset " + metadata.offset());
            } catch (ExecutionException e) {
                System.out.println("Error in sending record");
                System.out.println(e);
            } catch (InterruptedException e) {
                System.out.println("Error in sending record");
                System.out.println(e);
            }
        }
    }
    public static String encodeToString(BufferedImage image, String type) {
        String imageString = null;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            ImageIO.write(image, type, bos);
            byte[] imageBytes = bos.toByteArray();
            BASE64Encoder encoder = new BASE64Encoder();
            imageString = encoder.encode(imageBytes);
            bos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return imageString;
    }
    public static BufferedImage watermarkMethod(BufferedImage image) {
        Graphics2D g = image.createGraphics();
        g.setColor(Color.RED);
        g.drawRect(50, 50, 100, 100);
        //g.drawString("Watermarked",10,10);
        g.dispose();
        return image;
    }
    public static BufferedImage decodeToImage(String imageString) {
        BufferedImage image = null;
        byte[] imageByte;
        try {
            BASE64Decoder decoder = new BASE64Decoder();
            imageByte = decoder.decodeBuffer(imageString);
            ByteArrayInputStream bis = new ByteArrayInputStream(imageByte);
            image = ImageIO.read(bis);
            bis.close();} catch (Exception e) {
        }

        return image;
    }
    static String invocation(String imageParam){
        String output="";
        try {
            URL url = new URL("https://openwhisk.eu-gb.bluemix.net/api/v1/namespaces/mr.salehsedghpour%40yahoo.com_dev/triggers/Fork?image="+imageParam);
            HttpURLConnection hConn = (HttpURLConnection) url.openConnection();
            String authHeader = "Basic ZmZiYjljNWEtMGNjOC00NmMyLWE2ZTUtODUwMDIxMGFjZWJkOjJMblh0VkhjdU96QjdBazU0MEhld1FGZmtrUG5xdjBneUcxMzVnQmQxNFd4TmlhblQxdmNpOWxGMXV5ZVZ2eTU=";
            hConn.setRequestProperty(HttpHeaders.AUTHORIZATION, authHeader);
            hConn.setRequestProperty("Content-Type", "application/json");
            hConn.setRequestMethod("POST");
            hConn.setDoOutput(true);

            String input = "";

            OutputStream os = hConn.getOutputStream();
            os.write(input.getBytes());
            os.flush();
            os.close();

            if (hConn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                BufferedReader br =
                        new BufferedReader(new InputStreamReader(hConn.getInputStream()));

                while ((output = br.readLine()) != null) {
                    System.out.println(output);
                    System.out.println("Successfully Triggered the Fork Trigger");
                    Logger logger = Logger.getLogger("MyCustomlogger");
                    logger.logp(Level.INFO, "HelloWorld", "method", "INFO level message");

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return output;

    }


}