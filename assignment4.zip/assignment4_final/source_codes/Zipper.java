import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.apache.commons.codec.binary.Base64;
import org.lightcouch.CouchDbClient;
import sun.misc.BASE64Decoder;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;


public class Zipper  {
    public static JsonObject main(JsonObject args) {
        String enhancerString = getFromCouchdb("Enhancer");
        String grayscaleString = getFromCouchdb("grayscaled");
        if ((enhancerString != null)&&(grayscaleString != null)){


            try {
                BufferedImage enhancerImage = decodeToImage(enhancerString);
                BufferedImage grayscaleImage = decodeToImage(grayscaleString);
                File outputfile = new File("enhanced.jpg");
                ImageIO.write(enhancerImage, "jpg", outputfile);
                File outputfile2 = new File("grayscaled.jpg");
                ImageIO.write(grayscaleImage, "jpg", outputfile2);
                String zipFile = "archive.zip";

                String[] srcFiles = { "enhanced.jpg", "grayscaled.jpg"};
                // create byte buffer
                byte[] buffer = new byte[1024];

                FileOutputStream fos = new FileOutputStream(zipFile);

                ZipOutputStream zos = new ZipOutputStream(fos);

                for (int i=0; i < srcFiles.length; i++) {

                    File srcFile = new File(srcFiles[i]);

                    FileInputStream fis = new FileInputStream(srcFile);

                    // begin writing a new ZIP entry, positions the stream to the start of the entry data
                    zos.putNextEntry(new ZipEntry(srcFile.getName()));

                    int length;

                    while ((length = fis.read(buffer)) > 0) {
                        zos.write(buffer, 0, length);
                    }

                    zos.closeEntry();

                    // close the InputStream
                    fis.close();

                }

                // close the ZipOutputStream
                zos.close();
                String finalOutput = encodeFileToString(zipFile);
                saveToCouchdb(finalOutput);
                JsonObject response = new JsonObject();
                response.addProperty("Output", "Image has successfully zipped! ");
                return response;

            }
            catch (IOException ioe) {
                System.out.println("Error creating zip file: " + ioe);
            }
        }


        JsonObject response = new JsonObject();
        response.addProperty("Output", "Image has unsuccessfully zipped ");
        return response;
    }
    public static String encodeFileToString(String filepath){
        File originalFile = new File(filepath);
        String encodedBase64 = null;
        try {
            FileInputStream fileInputStreamReader = new FileInputStream(originalFile);
            byte[] bytes = new byte[(int)originalFile.length()];
            fileInputStreamReader.read(bytes);
            encodedBase64 = new String(Base64.encodeBase64(bytes));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return encodedBase64;
    }
    public static String saveToCouchdb(String image){
        CouchDbClient dbClient = new CouchDbClient("images", true, "http", "159.89.20.122", 5985, "admin", "assignment4");
        String id = "zipper";
        JsonObject json = new JsonObject();
        json.addProperty("_id", id);
        json.addProperty("name","zipper");
        json.addProperty("zipped",image);
        json.add("array", new JsonArray());
        dbClient.save(json);
        return id;
    }
    public static BufferedImage decodeToImage(String imageString) {
        BufferedImage image = null;
        byte[] imageByte;
        try {
            BASE64Decoder decoder = new BASE64Decoder();
            imageByte = decoder.decodeBuffer(imageString);
            ByteArrayInputStream bis = new ByteArrayInputStream(imageByte);
            image = ImageIO.read(bis);
            bis.close();} catch (Exception e) {
            System.out.println("mamad");
        }

        return image;
    }
    public static  String  getFromCouchdb(String imageID) {
        CouchDbClient dbClient = new CouchDbClient("images", true, "http", "159.89.20.122", 5985, "admin", "assignment4");
        JsonObject dbout = dbClient.find(JsonObject.class, imageID);
        String  image = dbout.get("image").getAsString();

        return image;
    }
}
