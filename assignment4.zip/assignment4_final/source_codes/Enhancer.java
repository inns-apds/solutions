import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.lightcouch.CouchDbClient;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.awt.image.RescaleOp;
import java.io.*;

public class Enhancer {
    public static JsonObject main(JsonObject args) {
        String imageString = getFromCouchdb("watermarked");
        BufferedImage image = decodeToImage(imageString);
        BufferedImage watermarkedImage = watermarkMethod(image);
        String watermarkedImageString = encodeToString(watermarkedImage,"jpg");
        String outputID = saveToCouchdb(watermarkedImageString);
        JsonObject response = new JsonObject();
        response.addProperty("Output", "Image has successfully watermarked! ");
        return response;
    }
    public static String saveToCouchdb(String image){
        String id="Enhancer";
        CouchDbClient dbClient = new CouchDbClient("images", true, "http", "159.89.20.122", 5985, "admin", "assignment4");
        JsonObject json = new JsonObject();
        json.addProperty("_id", id);
        json.addProperty("name","Enhancer");
        json.addProperty("image",image);
        json.add("array", new JsonArray());
        dbClient.save(json);
        return id;
    }
    public static String encodeToString(BufferedImage image, String type) {
        String imageString = null;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            ImageIO.write(image, type, bos);
            byte[] imageBytes = bos.toByteArray();
            BASE64Encoder encoder = new BASE64Encoder();
            imageString = encoder.encode(imageBytes);
            bos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return imageString;
    }


    public static BufferedImage watermarkMethod(BufferedImage image){
        float brightenFactor = 1.1f;
        RescaleOp op = new RescaleOp(brightenFactor, 0, null);
        image = op.filter(image, image);
        return image;
    }
    public static BufferedImage decodeToImage(String imageString) {
        BufferedImage image = null;
        byte[] imageByte;
        try {
            BASE64Decoder decoder = new BASE64Decoder();
            imageByte = decoder.decodeBuffer(imageString);
            ByteArrayInputStream bis = new ByteArrayInputStream(imageByte);
            image = ImageIO.read(bis);
            bis.close();} catch (Exception e) {
        }

        return image;
    }
    public static  String  getFromCouchdb(String imageID) {
        CouchDbClient dbClient = new CouchDbClient("images", true, "http", "159.89.20.122", 5985, "admin", "assignment4");
        JsonObject dbout = dbClient.find(JsonObject.class, imageID);
        String  image = dbout.get("image").getAsString();

        return image;
    }
}
