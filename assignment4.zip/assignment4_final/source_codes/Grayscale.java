import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.lightcouch.CouchDbClient;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;

public class Grayscale {
    public static JsonObject main(JsonObject args) {
        String imageString = getFromCouchdb("watermarked");
        BufferedImage image = decodeToImage(imageString);
        BufferedImage grayscaledImage = grayscaleMethod(image);
        String grayscaledImageString = encodeToString(grayscaledImage,"jpg");
        String outputID = saveToCouchdb(grayscaledImageString);
        JsonObject response = new JsonObject();
        response.addProperty("Output", "Image has successfully watermarked! ");
        return response;
    }
    public static String saveToCouchdb(String image){
        String id="grayscaled";
        CouchDbClient dbClient = new CouchDbClient("images", true, "http", "159.89.20.122", 5985, "admin", "assignment4");
        JsonObject json = new JsonObject();
        json.addProperty("_id", id);
        json.addProperty("name","grayscaled");
        json.addProperty("image",image);
        json.add("array", new JsonArray());
        dbClient.save(json);
        return id;
    }
    public static String encodeToString(BufferedImage image, String type) {
            String imageString = null;
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            try {
                ImageIO.write(image, type, bos);
                byte[] imageBytes = bos.toByteArray();
                BASE64Encoder encoder = new BASE64Encoder();
                imageString = encoder.encode(imageBytes);
                bos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return imageString;
        }
    public static BufferedImage grayscaleMethod(BufferedImage image){
        int width;
        int height;
        width = image.getWidth();
        height = image.getHeight();

        for(int i=0; i<height; i++) {

            for(int j=0; j<width; j++) {

                Color c = new Color(image.getRGB(j, i));
                int red = (int)(c.getRed() * 0.299);
                int green = (int)(c.getGreen() * 0.587);
                int blue = (int)(c.getBlue() *0.114);
                Color newColor = new Color(red+green+blue,

                        red+green+blue,red+green+blue);

                image.setRGB(j,i,newColor.getRGB());
            }
        }
        return image;
    }
    public static BufferedImage decodeToImage(String imageString) {
        BufferedImage image = null;
        byte[] imageByte;
        try {
            BASE64Decoder decoder = new BASE64Decoder();
            imageByte = decoder.decodeBuffer(imageString);
            ByteArrayInputStream bis = new ByteArrayInputStream(imageByte);
            image = ImageIO.read(bis);
            bis.close();} catch (Exception e) {
        }

        return image;
    }
    public static  String  getFromCouchdb(String imageID) {
        CouchDbClient dbClient = new CouchDbClient("images", true, "http", "159.89.20.122", 5985, "admin", "assignment4");
        JsonObject dbout = dbClient.find(JsonObject.class, imageID);
        String  image = dbout.get("image").getAsString();

        return image;
    }
}
