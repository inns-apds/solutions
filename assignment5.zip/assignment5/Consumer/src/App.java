import java.util.concurrent.ExecutionException;
import org.lightcouch.CouchDbClient;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

import constants.IKafkaConstants;
import consumer.ConsumerCreator;

public class App {

    public static JsonObject main(JsonObject args) {
        JsonObject response = new JsonObject();
        Consumer<Long, String> consumer = ConsumerCreator.createConsumer();

        int noMessageToFetch = 0;


        for (int index = 0; index < 5; index++) {
            final ConsumerRecords<Long, String> consumerRecords = consumer.poll(1000);
            if (consumerRecords.count() == 0) {
                noMessageToFetch++;
                if (noMessageToFetch > IKafkaConstants.MAX_NO_MESSAGE_FOUND_COUNT)
                    break;
                else
                    continue;
            }
            //System.out.println("Record Key " + record.key());
            //System.out.println("Record value " + record.value());
            //System.out.println("Record partition " + record.partition());
            //System.out.println("Record offset " + record.offset());
            //response.addProperty("value", record.value());
            //response.addProperty("partition", record.partition());
            //response.addProperty("offset", record.offset());
            //Long key= record.key();
            for (ConsumerRecord<Long, String> record : consumerRecords) {
                response.addProperty("Key", record.value());
                saveToCouchdb(record.value());
            }
            consumer.commitAsync();
        }
        consumer.close();
        //response.addProperty("test",key);
        return response;
    }
    public static String saveToCouchdb(String value){
        CouchDbClient dbClient = new CouchDbClient("assignment5", true, "http", "104.248.135.98", 5985, "admin", "123456");
        JsonObject json = new JsonObject();

        json.addProperty("key",value+ " by second Consumer");
        dbClient.save(json);
        return value;
    }

}