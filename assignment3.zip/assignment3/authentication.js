let contents;

function main(params) {

	        if(!contents) {
			                console.log('Read from the file system');
			                contents = fs.readFileSync(__dirname + '/usernames.json');
			                var usernames = JSON.parse(contents);
			        }
	        var found = false;
	        var username = params.name;
	        var password = params.password
	        for(var i = 0; i < usernames['emails'].length; i++) {
			            var n = usernames['emails'][i].localeCompare(username);
			            if (n == 0) {
					                    var m = password.localeCompare(1234);
					                    if (m == 0) {
								                    found = true;
								                    break;
								                    }
					                }
			        }
	        var msg = ""
	        if (found) {
			            msg = {body: `<html><body><h3>You have successfully logged in.</h3></body></html>`};
			        } else {
					            msg = {body: `<html><body><h3>You have Entered Wrong username/password.</h3></body></html>`};
					        }
	return msg;
}

exports.main = main;

