#!/usr/bin/env bash
rm temp.zip
wsk action delete -i authentication
zip  -rq temp.zip authentication.js usernames.json package.json
wsk action create authentication  --kind nodejs:default temp.zip -i --web yes
