#!/usr/bin/env bash
rm temp.zip
wsk action delete -i authentication
wsk action create hello  hello.js -i
wsk invoke hello -i --result
