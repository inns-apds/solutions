/**
 *  * Hello world as an OpenWhisk action.
 *   */
function main(params) {
	    var name = params.name || 'World';
	    return {payload:  'Hello, ' + name + '!'};
}


